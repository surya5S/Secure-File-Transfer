package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "register", urlPatterns = {"/register"})
public class register extends HttpServlet {

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            response.setContentType("text/html;charset=UTF-8");
            PrintWriter out = response.getWriter();
            
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/register","root","root");
            /*if(con==null)
                out.println("Null");
            else
                out.println("Exist");*/
            PreparedStatement ps;
            ResultSet res;
            int id = 0;
            String mail = null;
            String name1 = null;
            String name=request.getParameter("tb1");
            String pass=request.getParameter("tb2");
            String email=request.getParameter("tb4");
            String phone=request.getParameter("tb5");
            long ph=Long.parseLong(phone);
            String fk=request.getParameter("tb6");
            ps=con.prepareStatement("insert into users(username,password,email,phone,filekey) values(?,?,?,?,?)");
            ps.setString(1, name);
            ps.setString(2, pass);
            ps.setString(3, email);
            ps.setLong(4, ph);
            ps.setString(5, fk);
            int i=ps.executeUpdate();
            res=ps.executeQuery("select * from users;");
	    while(res.next()){
		id=res.getInt("id");
                mail=res.getString("email");
                name1=res.getString("username");
	    }
            
            
            /*ServletContext sc=getServletContext();
            sc.setAttribute("s1",id);
            sc.setAttribute("s2",mail);
            RequestDispatcher rs=sc.getRequestDispatcher("/sendmail");
            rs.forward(request, response);
            //out.println(id);*/
           Properties properties=new Properties();
            
            properties.put("mail.smtp.auth","true");
            properties.put("mail.smtp.starttls.enable","true");
            properties.put("mail.smtp.host","smtp.gmail.com");
            properties.put("mail.smtp.port","587");
            
            
            String myAcc="jyothiproject4@gmail.com";
            String pass1="Project@4";
            
            Session session =Session.getInstance(properties, new Authenticator(){
                @Override
                protected PasswordAuthentication getPasswordAuthentication(){
                    return new PasswordAuthentication(myAcc,pass1);
                }
            });  
            Message message=new MimeMessage(session);
            message.setFrom(new InternetAddress(myAcc));
            message.setRecipient(Message.RecipientType.TO,new InternetAddress(mail) );
            message.setSubject("Registration Success");
            message.setText("Your File key: "+fk);
            Transport.send(message);
            /*ps=con.prepareStatement("insert into filekeys(usrname,fkey) values(?,?)");
            ps.setString(1,name1 );
            ps.setInt(2, id);
            ps.executeUpdate();*/
            out.println("<div style=\"width:500px;height:625px;border:3px solid black;\" align=\"center\">");
            out.print("<h2>File Key sent to ur registered mail</h2>");
            if(i>0){
                out.println("<h2>Successfully registered......</h2>");
            
            out.println("<a href='index.html'>Back to Home Page</a>");
            }
            
            out.println("</div>");
        } catch (SQLException ex) {
            Logger.getLogger(register.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(register.class.getName()).log(Level.SEVERE, null, ex);
        } catch (AddressException ex) {
            Logger.getLogger(register.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MessagingException ex) {
            Logger.getLogger(register.class.getName()).log(Level.SEVERE, null, ex);
        }
           
        
         
      
    }

}

