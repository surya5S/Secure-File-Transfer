package com;
import com.amazonaws.AmazonClientException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.ClasspathPropertiesFileCredentialsProvider;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.transfer.TransferManager;
import com.amazonaws.services.s3.transfer.Upload;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

@WebServlet(name = "s3Upload", urlPatterns = {"/s3Upload"})
public class s3Upload extends HttpServlet {
    private static AWSCredentials credentials;
    private static TransferManager tx;
    private static String bucketName;
    private Upload upload;
   // private static SecretKeySpec secretKey;
    //private static byte[] key;
    private static String user=null;
   // private static String name=null;
   // private static String k=null;
    //private static String sessionID=null;
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, FileUploadException, Exception {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter(); 
        String name=null;
        String k=null;
        String sessionID=null;
        try{
        HttpSession session=request.getSession(false);
        if(session.getAttribute("user") == null){
                    response.sendRedirect("login.html");
        }else user = (String) session.getAttribute("user");
        boolean isMultiPart = ServletFileUpload.isMultipartContent(request);
        FileItemFactory factory=new DiskFileItemFactory();
        ServletFileUpload uploader=new ServletFileUpload(factory);
        
        AmazonS3 s3 = new AmazonS3Client(credentials = new ClasspathPropertiesFileCredentialsProvider().getCredentials());
        java.security.Security.setProperty("networkaddress.cache.ttl" , "60");

        Region usWest2 = Region.getRegion(Regions.US_WEST_2);
        s3.setRegion(usWest2);
        tx=new TransferManager(s3);
        
        bucketName="bucket-"+user;
        createAmazonS3Bucket();
        
        List items=null;
        items=uploader.parseRequest(request);
        Iterator itr=items.iterator();
        while(itr.hasNext()){
            FileItem item=(FileItem)itr.next();
            if(item.getName()!=null)
            {
                System.out.println("File Name:"+item.toString());
                System.out.println("File Name:"+item.getName());
                //Cookies
                session=request.getSession(false);
                if(session.getAttribute("user") == null){
                    response.sendRedirect("login.html");
                }else user = (String) session.getAttribute("user");
                Cookie[] cookies = request.getCookies();
                if(cookies !=null){
                for(Cookie cookie : cookies){
                if(cookie.getName().equals("username")) name = cookie.getValue();
                if(cookie.getName().equals("JSESSIONID")) sessionID = cookie.getValue();
                if(cookie.getName().equals("key")) k = cookie.getValue();
                }
                }
             
                
                
                File savedFile = new File(item.getName());
                item.write(savedFile);
                //Encryption
                byte[] b=encrypt(Cipher.ENCRYPT_MODE,savedFile,k);
                File encryptedFile = new File("F:\\files2\\"+item.getName().substring(3));
                FileOutputStream outputStream = new FileOutputStream(encryptedFile);
	        outputStream.write(b);
                PutObjectRequest reqObj=new PutObjectRequest(bucketName,item.getName().substring(3),encryptedFile);
                System.out.println("File Name:"+item.getName());
                upload=tx.upload(reqObj);
                if(upload.isDone()==false)
                {
                    System.out.println("Transfer:"+upload.getDescription());
                    System.out.println("Transfer:"+upload.getState());
                    System.out.println("Transfer:"+upload.getProgress().getBytesTransferred());
                    
                       
                }
               // out.println("Uploading...");
                upload.waitForCompletion();
                out.print("File Upload Successful");
                encryptedFile.delete();
                
                
            }
            
        }
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            out.close();
        }
        
    }
    private void createAmazonS3Bucket() {
        try{
        if(tx.getAmazonS3Client().doesBucketExist(bucketName)== false)
        {
            tx.getAmazonS3Client().createBucket(bucketName);
        }
        }
        catch(AmazonClientException ace){
            ace.printStackTrace();
        }
    }
  
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (Exception ex) {
            Logger.getLogger(s3Upload.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private byte[] encrypt(int cipherMode, File inputFile, String key) throws NoSuchAlgorithmException, IOException {
        try {
          
            MessageDigest messageDigest = MessageDigest.getInstance("MD5");
            byte[] b=messageDigest.digest(key.getBytes());
            b = Arrays.copyOf(b, 16);
            SecretKeySpec secretKey = new SecretKeySpec(b, "AES");
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(cipherMode, secretKey);
            
            FileInputStream inputStream = new FileInputStream(inputFile);
            byte[] inputBytes = new byte[(int) inputFile.length()];
            inputStream.read(inputBytes);
            
            byte[] outputBytes = cipher.doFinal(inputBytes);
            return outputBytes;
        } catch (NoSuchPaddingException ex) {
            Logger.getLogger(s3Upload.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InvalidKeyException ex) {
            Logger.getLogger(s3Upload.class.getName()).log(Level.SEVERE, null, ex);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(s3Upload.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalBlockSizeException ex) {
            Logger.getLogger(s3Upload.class.getName()).log(Level.SEVERE, null, ex);
        } catch (BadPaddingException ex) {
            Logger.getLogger(s3Upload.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
       
    }
    
}
