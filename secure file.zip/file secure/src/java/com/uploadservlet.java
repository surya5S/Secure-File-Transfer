
package com;

import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import java.security.SecureRandom;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.File;  
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.security.Key;
import java.util.List;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;


@WebServlet(name = "uploadservlet", urlPatterns = {"/uploadservlet"})
public class uploadservlet extends HttpServlet {

     private static final long serialVersionUID = 1L;
     private final String UPLOAD_DIRECTORY = "F:/files";
     String fname = null;
     String fsize = null;
     String ftype = null;
     private static Key generateKey(String productkey) {
         String keyValue=productkey;         
        Key key = new SecretKeySpec(keyValue.getBytes(), "AES");        
        return key;
    }   
     @Override
     protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         HttpSession session=request.getSession();
      if(ServletFileUpload.isMultipartContent(request)){
            try {
               PrintWriter out =response.getWriter();
               List<FileItem> multiparts = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);

               for(FileItem item : multiparts){
                    if(!item.isFormField()){
                        fname = new File(item.getName()).getName();
                        fsize = new Long(item.getSize()).toString();
                        session.setAttribute("filename",item.getName());
                        session.setAttribute("filesize",item.getSize());
                        ftype = item.getContentType();
       
                        item.write( new File(UPLOAD_DIRECTORY + File.separator + fname));
                    }
                    
                }
                
               
               //File uploaded successfully
               out.println("File uploaded successfully");
               String filePath = "F:/files/"+fname;
               
	       String plainText=usingBufferedReader( filePath );
	       
		KeyGenerator keyGenerator=KeyGenerator.getInstance("AES");
		keyGenerator.init(128);
		SecretKey key=keyGenerator.generateKey();
		
		
		byte[] IV=new byte[16];
		SecureRandom random=new SecureRandom();
		random.nextBytes(IV);
		
		
		//System.out.println("original Text:"+plainText);
		byte[] cipherText=encrypt(plainText.getBytes(),key,IV);
                session.setAttribute("key",key);
                session.setAttribute("init",IV);
		File file = new File(UPLOAD_DIRECTORY + File.separator + fname+".enc");
                OutputStream os  = new FileOutputStream(file); 
                os.write(cipherText);
                os.close();
                out.print("Encrypted");
               
               request.setAttribute("message", "File Uploaded Successfully");
               request.setAttribute("name", fname);
               request.setAttribute("size", fsize);
               request.setAttribute("type", ftype);
            } catch (Exception ex) {
               request.setAttribute("message", "File Upload Failed due to " + ex);
            }          
         
        }else{
            request.setAttribute("message","Sorry this Servlet only handles file upload request");
        }
        
        request.getRequestDispatcher("/result.jsp").forward(request, response);
    
       
     
    }     
    public static String usingBufferedReader(String filePath) 
    {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) 
        {
 
            String sCurrentLine;
            while ((sCurrentLine = br.readLine()) != null) 
            {
                sb.append(sCurrentLine).append("\n");
            }
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
        }
        return sb.toString();
    }  
   public static byte[] encrypt(byte[] plaintext,SecretKey key,byte[] IV) throws Exception{
		Cipher cipher=Cipher.getInstance("AES/CBC/PKCS5Padding");
		SecretKeySpec keySpec=new SecretKeySpec(key.getEncoded(),"AES");
		IvParameterSpec ivspec=new IvParameterSpec(IV);
		cipher.init(Cipher.ENCRYPT_MODE,keySpec,ivspec);
		byte[] cipherText=cipher.doFinal(plaintext);
		return cipherText;
	}
         
         
        
}
