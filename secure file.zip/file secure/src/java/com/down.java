
package com;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.ClasspathPropertiesFileCredentialsProvider;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.*;
import com.amazonaws.services.s3.transfer.TransferManager;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;

@WebServlet(name = "down", urlPatterns = {"/down"})
public class down extends HttpServlet {
    private static AWSCredentials credentials;
    private static TransferManager tx;
     private static String user=null;
    @Override
    protected void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException{
         ObjectListing object_listing ;
        PrintWriter out=response.getWriter();
        AmazonS3 s3 = new AmazonS3Client(credentials = new ClasspathPropertiesFileCredentialsProvider().getCredentials());
        java.security.Security.setProperty("networkaddress.cache.ttl" , "60");
        com.amazonaws.regions.Region usWest2 = com.amazonaws.regions.Region.getRegion(Regions.US_WEST_2);
        s3.setRegion(usWest2);
        tx=new TransferManager(s3);
        //List<Bucket> buckets = s3.listBuckets();
        out.println("Your Amazon S3 bucket is:");
       // for (Bucket b : buckets) {
            //out.println("* " + b.getName());
             HttpSession session=request.getSession(false);
            if(session.getAttribute("user") == null){
                    response.sendRedirect("login.html");
            }else user = (String) session.getAttribute("user");
            out.println("\nObjects are:");
            object_listing = s3.listObjects("bucket-"+user);
            List<S3ObjectSummary> list = object_listing.getObjectSummaries();
            for(S3ObjectSummary image: list) {
                  S3Object obj = s3.getObject("bucket-"+user, image.getKey());
                  out.print("\n"+obj+"\n");
            }       
            
        
       
        request.getRequestDispatcher("/down2.html").include(request, response);
        
        //S3Object s3object = s3.getObject("bucket1akia2fmu5r74ocok236r", "E:\\regform.txt");
        //S3ObjectInputStream inputStream = s3object.getObjectContent();
        //FileUtils.copyInputStreamToFile(inputStream, new File("F:\\files\\j.txt"));
        //out.println("\n\nDownloaded");
        
    }
    
}
