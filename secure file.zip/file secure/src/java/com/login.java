
package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet(name = "login", urlPatterns = {"/login"})
public class login extends HttpServlet {
      
     
    @Override
    protected void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException{
        try {
            String key1;
            PrintWriter out=response.getWriter();
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/register","root","root");
            String name=request.getParameter("tb1");
            String pass=request.getParameter("tb2");
            Statement stmt = null;
            PreparedStatement ps;
            //PreparedStatement ps1;
            ResultSet res=null;
            ps=con.prepareStatement("select * from users where username=? and password=?");
            ps.setString(1,name);
            ps.setString(2, pass);
            res=ps.executeQuery();
           
            
            res.next();
            if(res!=null){
                key1=res.getString("filekey");
                PreparedStatement ps1=con.prepareStatement("insert into filekeys(name,filekey) values(?,?)");
                ps1.setString(1,name);
                ps1.setString(2, key1);
                ps1.executeUpdate();
                out.println("Login Successful");
                HttpSession session = request.getSession();
                session.setAttribute("user",name);
                session.setMaxInactiveInterval(10*60);
                Cookie ck1 = new Cookie("username",name);
                Cookie ck2=new Cookie("key",key1);
                
		//setting cookie to expiry in 10 mins
                ck1.setMaxAge(10*60);
                response.addCookie(ck1);
		response.addCookie(ck2);
                
                out.println("<br/> <a href='upload.html'  style='width:30%'>File Upload</a><br/><br/>");
                out.println("<br/> <a href='getObjects.html'  style='width:30%'>File Download</a><br/><br/>");
                out.println(" <a href='logout'  style='width:30%'>logout</a>");
            }
            else{
                out.println("Unsuccessful<a href='login.html'>GoBack</a>");
            }
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(login.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(login.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
