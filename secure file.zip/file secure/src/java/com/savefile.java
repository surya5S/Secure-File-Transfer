
package com;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.ClasspathPropertiesFileCredentialsProvider;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.services.s3.transfer.TransferManager;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.Key;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.commons.io.FileUtils;


@WebServlet(name = "savefile", urlPatterns = {"/savefile"})
public class savefile extends HttpServlet {
        private static AWSCredentials credentials;
        private static TransferManager tx;
        private static String user=null;
        @Override
        protected void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException, FileNotFoundException
        {
            try {
                String name=null;
                String k=null;
                String sessionID=null;
                PrintWriter out=response.getWriter();
                String s1=request.getParameter("tb1");
                String s2=request.getParameter("tb2");
                String key=request.getParameter("tb3");
                //Check the key
                 HttpSession session=request.getSession(false);
                if(session.getAttribute("user") == null){
                    response.sendRedirect("login.html");
                }else user = (String) session.getAttribute("user");
                Cookie[] cookies = request.getCookies();
                if(cookies !=null){
                for(Cookie cookie : cookies){
                if(cookie.getName().equals("username")) name = cookie.getValue();
                if(cookie.getName().equals("JSESSIONID")) sessionID = cookie.getValue();
                if(cookie.getName().equals("key")) k = cookie.getValue();
                }
                }
                if(k.equals(key)){
                
                AmazonS3 s3 = new AmazonS3Client(credentials = new ClasspathPropertiesFileCredentialsProvider().getCredentials());
                java.security.Security.setProperty("networkaddress.cache.ttl" , "60");
                com.amazonaws.regions.Region usWest2 = com.amazonaws.regions.Region.getRegion(Regions.US_WEST_2);
                s3.setRegion(usWest2);
                tx=new TransferManager(s3);
                S3Object s3object = s3.getObject(s1, s2);
                S3ObjectInputStream inputStream = s3object.getObjectContent();
                FileUtils.copyInputStreamToFile(inputStream, new File("F:\\files2\\"+s2));
                File f1=new File("F:\\files2\\"+s2);
                String s=decrypt(Cipher.DECRYPT_MODE,f1,key);
                f1.setWritable(true);
                FileWriter fw=new FileWriter(f1);
                
                fw.write(s);
                fw.flush();
                fw.close();
                
                out.println("\nFile is successfully Downloaded");
                }
                else
                {
                    out.print("Please enter a valid file key");
                }
            } catch (NoSuchAlgorithmException ex) {
                Logger.getLogger(savefile.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        private String decrypt(int cipherMode, File inputFile, String key) throws NoSuchAlgorithmException, FileNotFoundException 
        {
            try {
                MessageDigest messageDigest = MessageDigest.getInstance("MD5");
                byte[] b=messageDigest.digest(key.getBytes());
                b = Arrays.copyOf(b, 16);
                SecretKeySpec secretKey = new SecretKeySpec(b, "AES");
                Cipher cipher = Cipher.getInstance("AES");
                cipher.init(cipherMode, secretKey);
                
                FileInputStream inputStream = new FileInputStream(inputFile);
                byte[] inputBytes = new byte[(int) inputFile.length()];
                inputStream.read(inputBytes);
                
                byte[] outputBytes = cipher.doFinal(inputBytes);
                String s=new String(outputBytes);
                return s;
                
            } catch (Exception ex) {
                System.out.print(ex);
            } 
            return null;
        }
   
}
